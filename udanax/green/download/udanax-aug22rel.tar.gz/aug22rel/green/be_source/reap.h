/* Copyright � 1979-1999 Udanax.com. All rights reserved.

* This code is licensed under the terms of The Udanax Open-Source License, 
* which contains precisely the terms of the X11 License.  The full text of 
* The Udanax Open-Source License can be found in the distribution in the file 
* license.html.  If this file is absent, a copy can be found at 
* http://udanax.xanadu.com/license.html and http://www.udanax.com/license.html
*/
 /* age values */
#ifndef RESERVED
#define RESERVED 0xff     /* keeps a crum from being reaped */
#define NEW 0
#define OLD 1           /* set this as you wish, age */
                        /*  up to it from NEW */
#endif

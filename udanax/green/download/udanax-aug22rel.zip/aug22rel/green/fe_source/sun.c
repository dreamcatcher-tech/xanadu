/* Copyright � 1979-1999 Udanax.com. All rights reserved.

* This code is licensed under the terms of The Udanax Open-Source License, 
* which contains precisely the terms of the X11 License.  The full text of 
* The Udanax Open-Source License can be found in the distribution in the file 
* license.html.  If this file is absent, a copy can be found at 
* http://udanax.xanadu.com/license.html and http://www.udanax.com/license.html
*/
/***************************************************
  Copyright (c) 1987 Xanadu Operating Company
  XU.87.1 Frontend Source Code:         sun.d
***************************************************/

#include "fest.h"

#ifdef COMMENT
  void
decideifwindow()
{
	iswindow= FALSE;
}

  void
getgraphicscreensize(x,y)
  med *x,*y;
{
}
#endif COMMENT

  void
winblockclear(x,y,w,h)
  nat x,y,w,h;
{
}

  void
winblockmove(x,y,w,h,x2,y2)
  nat x,y,w,h,x2,y2;
{
}
#ifdef COMMENT
  void
graphbox()
{
}
  void
pw_char()
{
}

#endif COMMENT
